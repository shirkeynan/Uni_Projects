#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

#define MAX_SIZE 255

int replace(const char *input_file, const char *output_file, const char *str1, const char *str2);

int replace(const char *input_file, const char *output_file, const char *str1, const char *str2)
{
    int count = 0;
    fpos_t pos;
    FILE *input, *output;
    char letter[1] = "";
    char buffer[MAX_SIZE] = "";
    char word[MAX_SIZE] = "";

    input = fopen(input_file,"r");
    output = fopen(output_file,"w");

    if (NULL == input || NULL == output) {  //Could'nt open file
        return -1;
    }

    fgets(letter, 2, (FILE*)input); //Gets a letter
    while(!feof(input)) {
        if (letter[0] == str1[0]) { //Might be the beginning of str1
            fgetpos(input, &pos); //Save pos in case not
            fgets(buffer, strlen(str1), (FILE*)input); 
            strncat(word, letter,1); 
            strncat(word, buffer, strlen(str1));  //word: helld
            if (0 == strcmp(word,str1)) { //Found str1
                fprintf(output, "%s", str2);  
                count++;
            } else {
                fprintf(output, "%c", letter[0]);
                fsetpos(input, &pos); 
            } 
        } else {
            fprintf(output, "%s", letter);
        }
        //Reset 
        memset(letter, 0, 1);
        memset(buffer, 0, MAX_SIZE);
        memset(word, 0, MAX_SIZE);

        fgets(letter, 2, (FILE*)input);
    }

    fclose(output);
    fclose(input);

    return count;
}