#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct node_rec {
 int data;
 struct node_rec *next;
} node_t;

void free_list(node_t *head);
node_t *zig_zag_lists(node_t *h1, node_t *h2);
node_t *create_node(int data);
node_t *add_first(node_t *head, int data);

node_t *create_node(int data)
{
    node_t *new = malloc(sizeof *new);
    if (new != NULL) {
        new->data = data;
        new->next = NULL;
    }
    return new;
}

void free_list(node_t *head)
{
    while (head != NULL) {
        node_t *temp = head;
        head = head->next;
        free(temp);
    }
} 

node_t *add_last(node_t *head, int data)
{
    node_t *new_node = create_node(data);
    if (NULL == new_node) {
        free_list(head);
        return NULL;
    }
    
    if (NULL == head)
        return new_node;

    node_t *tail = head;
    while (tail->next != NULL) {
        tail = tail->next; 
    }
    tail->next = new_node;
    return head;
}


node_t *zig_zag_lists(node_t *h1,node_t *h2)
{

    if ((NULL == h1 && h2 != NULL) || (NULL == h2 && h1 != NULL)) {
        return NULL;
    }

    node_t *new;
    node_t *ptr;
    int flag;

    if (h1 != NULL) {
        new = create_node(h1->data);
        ptr = new;
        h1 = h1->next;
        flag = 2;
    }
    
    while (h1 != NULL && h2 != NULL) {
        if (flag == 2) {
            new = add_last(ptr, h2->data);
            h2 = h2->next;
            flag = 1;
        } else if (flag == 1) {
            new = add_last(ptr, h1->data);
            h1 = h1->next;
            flag = 2;
        }
    }

    if (NULL == h1 && h2 != NULL) {
        while (h2!=NULL) {
            new = add_last(ptr, h2->data);
            h2 = h2->next;
        }
    }
    if (NULL == h2 && h1 != NULL) {
        while(h1!=NULL){
            new = add_last(ptr, h1->data);
            h1 = h1->next;
        }

    }
    return new;
}
